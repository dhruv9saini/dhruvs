# Paper source

This package rebuilds the three-page IEEE-format paper **Flood-Aware Feeder Protection: Served Load and Backup Feasibility**.

Compile the supplied TeX and vector figures with Tectonic 0.16.9:

```sh
tectonic flood_grid_ieee.tex
```

The unmodified IEEEtran conference class is included with its original license notice. The paper uses embedded Times-family text fonts, two numeric tables, two vector figures and direct links to the experiment's source and full results.

The complete numerical reproduction package is available at:

https://dhruvs.vercel.app/research/flood-grid/reproducibility.zip

The full retained result file is available at:

https://dhruvs.vercel.app/research/flood-grid/files/reference/study.json.xz

That package contains all original simulation and report sources, four native feeder inputs, the flood raster, the exact Python environment, execution instructions, all 360 scenarios and 11,880 solves, and the integrity and aggregate-result checkers.

To regenerate the figures, install Matplotlib 3.11.1 and run:

```sh
python plot_backup_island.py
python plot_feasibility.py
tectonic flood_grid_ieee.tex
```

Figure generation was checked with Python 3.14.6 and Matplotlib 3.11.1. The included vector PDFs allow the paper to be compiled without a Python installation. The branch diagram uses the retained seed-2203 example in `backup_example.json`; its connected loads and lines come from the native feeder files in the numerical reproduction package. The pooled-feasibility chart uses `summary.json`.

`MANIFEST.json` records every bundled input's size and SHA-256 hash. The supplied Markdown contains the complete paper text and tables.
