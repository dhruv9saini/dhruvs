import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle

ROOT=Path(__file__).resolve().parent
example=json.loads((ROOT/'backup_example.json').read_text())
source=example['source_violations'][0]
assert example['seed']==2203 and example['failed_assets']==['A','D']
assert round(source['apparent_kva'],2)==67.14
plt.rcParams.update({'font.family':'serif','font.size':8,'pdf.fonttype':42,'ps.fonttype':42})
fig,ax=plt.subplots(figsize=(3.45,2.3))
ax.set_xlim(0,3.7)
ax.set_ylim(0,2.65)
ax.axis('off')
line={'color':'black','linewidth':.9}
ax.plot([.1,.65],[1.35,1.35],**line)
ax.plot([.65,.92],[1.35,1.58],**line)
for x in [.65,1.02]:
    ax.add_patch(Circle((x,1.35),.025,facecolor='white',edgecolor='black',linewidth=.8))
ax.plot([1.045,1.65,3.05],[1.35,1.35,1.35],**line)
ax.text(.1,1.07,'Feeder',ha='left',va='top',fontsize=7.5)
ax.text(.82,1.75,'L83 open',ha='center',va='bottom',fontsize=7.5)
ax.text(2.35,1.47,'L85',ha='center',va='bottom',fontsize=7.5)
ax.plot([1.65,1.65],[1.35,1.9],**line)
ax.add_patch(Circle((1.65,2.07),.17,facecolor='white',edgecolor='black',linewidth=.9))
ax.text(1.65,2.07,'~',ha='center',va='center',fontsize=15)
ax.text(1.65,2.48,'60-kVA backup',ha='center',va='center',fontsize=8)
ax.text(2.55,2.1,f"Solved source\n{source['apparent_kva']:.2f} kVA\n{source['current_a']:.2f} A",ha='center',va='center',fontsize=7.5)
for x,bus in [(1.65,'84'),(3.05,'85')]:
    ax.plot([x,x],[1.35,.91],**line)
    ax.plot(x,1.35,'o',color='black',markersize=2.5)
    ax.text(x+.08,1.13,'Bus '+bus,ha='left',va='center',fontsize=7)
ax.add_patch(Rectangle((1.07,.23),1.15,.68,facecolor='white',edgecolor='black',linewidth=.8))
ax.add_patch(Rectangle((2.47,.23),1.15,.68,facecolor='white',edgecolor='black',linewidth=.8))
ax.text(1.645,.57,'Critical S84c\n20 kW + 10 kvar\n0.990 pu',ha='center',va='center',fontsize=7.4)
ax.text(3.045,.57,'Ordinary S85c\n40 kW + 20 kvar',ha='center',va='center',fontsize=7.4)
fig.subplots_adjust(left=.01,right=.99,top=.99,bottom=.01)
fig.savefig(ROOT/'backup_island.pdf',metadata={'CreationDate':None,'ModDate':None})
fig.savefig(ROOT/'backup_island.svg',metadata={'Date':None})
plt.close(fig)
