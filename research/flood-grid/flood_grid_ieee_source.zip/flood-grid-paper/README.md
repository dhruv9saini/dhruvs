# Paper source

This package rebuilds the three-page IEEE-format paper **Flood-Aware Feeder Protection: Served Load and Backup Feasibility**.

Compile the supplied TeX source with Tectonic 0.16.9:

```sh
tectonic flood_grid_ieee.tex
```

The unmodified IEEEtran conference class is included with its original license notice. The paper uses embedded Times-family text fonts, two numeric tables and direct links to the experiment's source and full results.

The complete numerical reproduction package is available at:

https://dhruvs.vercel.app/research/flood-grid/reproducibility.zip

The full retained result file is available at:

https://dhruvs.vercel.app/research/flood-grid/files/reference/study.json.xz

That package contains all original simulation and report sources, four native feeder inputs, the flood raster, the exact Python environment, execution instructions, all 360 scenarios and 11,880 solves, and the integrity and aggregate-result checkers.

`MANIFEST.json` records every bundled input's size and SHA-256 hash. The supplied Markdown contains the complete paper text and tables.
