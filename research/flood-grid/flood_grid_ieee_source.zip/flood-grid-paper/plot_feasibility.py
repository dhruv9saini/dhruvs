import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'summary.json').read_text())['campaign_accounting']
totals=[data['retained_hardening_policy_result_count'],data['retained_backup_policy_result_count']]
failed=[data['infeasible_retained_hardening_policy_result_count'],data['infeasible_retained_backup_policy_result_count']]
passed=[n-f for n,f in zip(totals,failed)]
plt.rcParams.update({'font.family':'serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
fig,ax=plt.subplots(figsize=(3.45,2.0))
ax.barh([1,0],passed,height=0.44,color='white',edgecolor='black',linewidth=.7,label='Feasible')
ax.barh([1,0],failed,left=passed,height=0.44,color='#a7a7a7',edgecolor='black',linewidth=.7,label='Infeasible')
for y,a,b in zip([1,0],passed,failed):
    ax.text(a/2,y,f'{a:,}',ha='center',va='center',fontsize=8)
    ax.text(a+b/2,y,f'{b:,}',ha='center',va='center',fontsize=8)
ax.set_yticks([1,0],['Hardening','Backup'])
ax.set_xlim(0,6500)
ax.set_xticks([0,2000,4000,6000],['0','2,000','4,000','6,000'])
ax.set_xlabel('Retained policy solves')
ax.tick_params(axis='y',length=0)
ax.legend(loc='lower center',bbox_to_anchor=(.5,1.04),ncol=2,frameon=False,handlelength=1.3,columnspacing=1.6)
fig.subplots_adjust(left=.23,right=.99,bottom=.29,top=.75)
fig.savefig(ROOT/'feasibility.pdf',metadata={'CreationDate':None,'ModDate':None})
fig.savefig(ROOT/'feasibility.svg',metadata={'Date':None})
plt.close(fig)
(ROOT/'figure_data.json').write_text(json.dumps({'policy':['Hardening','Backup'],'total':totals,'feasible':passed,'infeasible':failed},indent=2)+'\n')
print(json.dumps({'figure_created':True,'feasible':passed,'infeasible':failed}))
